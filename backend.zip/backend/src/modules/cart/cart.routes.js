const express = require('express');
const authenticate = require('../../middleware/auth');
const cartController = require('./cart.controller');

const router = express.Router();

router.use(authenticate);

router.post('/items', cartController.addItem);
router.get('/', cartController.getCart);
router.put('/items/:itemId', cartController.updateItem);
router.delete('/items/:itemId', cartController.deleteItem);

module.exports = router;