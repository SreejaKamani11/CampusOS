const { pool } = require('../../config/database');

function buildCart(rows) {
  if (rows.length === 0) {
    return null;
  }

  const firstRow = rows[0];

  const cart = {
    id: firstRow.cart_id,
    user_id: firstRow.user_id,
    created_at: firstRow.cart_created_at,
    updated_at: firstRow.cart_updated_at,
    items: [],
  };

  for (const row of rows) {
    if (!row.item_id) {
      continue;
    }

    cart.items.push({
      id: row.item_id,
      service_type: row.service_type,
      reference_id: row.reference_id,
      quantity: row.quantity,
      options: row.options,
      unit_price: row.unit_price,
      subtotal: Number(row.quantity) * Number(row.unit_price),
      created_at: row.item_created_at,
      updated_at: row.item_updated_at,
      product: {
        id: row.product_id,
        category_id: row.category_id,
        category_name: row.category_name,
        name: row.product_name,
        description: row.product_description,
        price: row.product_price,
        stock: row.product_stock,
        image_url: row.product_image_url,
        active: row.product_active,
        created_at: row.product_created_at,
        updated_at: row.product_updated_at,
      },
    });
  }

  return cart;
}

async function withTransaction(work) {
  const client = await pool.connect();

  try {
    await client.query('BEGIN');
    const result = await work(client);
    await client.query('COMMIT');
    return result;
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}

async function findOrCreateCart(client, userId) {
  const result = await client.query(
    `WITH inserted AS (
       INSERT INTO carts (user_id)
       VALUES ($1)
       ON CONFLICT (user_id) DO NOTHING
       RETURNING id, user_id, created_at, updated_at
     )
     SELECT id, user_id, created_at, updated_at
     FROM inserted
     UNION ALL
     SELECT id, user_id, created_at, updated_at
     FROM carts
     WHERE user_id = $1
     LIMIT 1`,
    [userId]
  );

  return result.rows[0];
}

async function findProductById(client, productId) {
  const result = await client.query(
    `SELECT
       sp.id,
       sp.category_id,
       sc.name AS category_name,
       sp.name,
       sp.description,
       sp.price,
       sp.stock,
       sp.image_url,
       sp.active,
       sp.created_at,
       sp.updated_at
     FROM stationery_products sp
     LEFT JOIN stationery_categories sc
       ON sc.id = sp.category_id
     WHERE sp.id = $1`,
    [productId]
  );

  return result.rows[0] || null;
}

async function findCartItemById(client, cartId, itemId) {
  const result = await client.query(
    `SELECT id, quantity
     FROM cart_items
     WHERE id = $1
       AND cart_id = $2
       AND service_type = 'stationery'`,
    [itemId, cartId]
  );

  return result.rows[0] || null;
}

async function findCartItemByReferenceId(client, cartId, referenceId) {
  const result = await client.query(
    `SELECT id, quantity
     FROM cart_items
     WHERE cart_id = $1
       AND reference_id = $2
       AND service_type = 'stationery'`,
    [cartId, referenceId]
  );

  return result.rows[0] || null;
}

async function getCartRows(client, userId) {
  const result = await client.query(
    `SELECT
       c.id AS cart_id,
       c.user_id,
       c.created_at AS cart_created_at,
       c.updated_at AS cart_updated_at,
       ci.id AS item_id,
       ci.service_type,
       ci.reference_id,
       ci.quantity,
       ci.options,
       ci.unit_price,
       ci.created_at AS item_created_at,
       ci.updated_at AS item_updated_at,
       sp.id AS product_id,
       sp.category_id,
       sc.name AS category_name,
       sp.name AS product_name,
       sp.description AS product_description,
       sp.price AS product_price,
       sp.stock AS product_stock,
       sp.image_url AS product_image_url,
       sp.active AS product_active,
       sp.created_at AS product_created_at,
       sp.updated_at AS product_updated_at
     FROM carts c
     LEFT JOIN cart_items ci
       ON ci.cart_id = c.id
      AND ci.service_type = 'stationery'
     LEFT JOIN stationery_products sp
       ON sp.id = ci.reference_id
     LEFT JOIN stationery_categories sc
       ON sc.id = sp.category_id
     WHERE c.user_id = $1
     ORDER BY ci.created_at ASC NULLS LAST`,
    [userId]
  );

  return buildCart(result.rows);
}

async function getCartByUserId(userId) {
  return withTransaction(async (client) => {
    await findOrCreateCart(client, userId);
    return getCartRows(client, userId);
  });
}

async function addItemToCart({ userId, productId, quantity }) {
  return withTransaction(async (client) => {
    const product = await findProductById(client, productId);

    if (!product) {
      return null;
    }

    const cart = await findOrCreateCart(client, userId);

    const existingItem = await findCartItemByReferenceId(client, cart.id, productId);

    if (existingItem) {
      await client.query(
        `UPDATE cart_items
         SET quantity = quantity + $1
         WHERE id = $2`,
        [quantity, existingItem.id]
      );
    } else {
      await client.query(
        `INSERT INTO cart_items (
           cart_id,
           service_type,
           reference_id,
           quantity,
           options,
           unit_price
         )
         VALUES ($1, 'stationery', $2, $3, $4, $5)`,
        [cart.id, productId, quantity, {}, product.price]
      );
    }

    return getCartRows(client, userId);
  });
}

async function updateCartItemQuantity({ userId, itemId, quantity }) {
  return withTransaction(async (client) => {
    const cart = await findOrCreateCart(client, userId);
    const existingItem = await findCartItemById(client, cart.id, itemId);

    if (!existingItem) {
      return null;
    }

    await client.query(
      `UPDATE cart_items
       SET quantity = $1
       WHERE id = $2`,
      [quantity, itemId]
    );

    return getCartRows(client, userId);
  });
}

async function deleteCartItem({ userId, itemId }) {
  return withTransaction(async (client) => {
    const cart = await findOrCreateCart(client, userId);
    const existingItem = await findCartItemById(client, cart.id, itemId);

    if (!existingItem) {
      return null;
    }

    await client.query(
      `DELETE FROM cart_items
       WHERE id = $1`,
      [itemId]
    );

    return getCartRows(client, userId);
  });
}

module.exports = {
  getCartByUserId,
  addItemToCart,
  updateCartItemQuantity,
  deleteCartItem,
};